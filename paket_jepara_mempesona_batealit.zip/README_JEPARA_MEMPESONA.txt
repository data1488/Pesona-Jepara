PAKET WEBSITE JEPARA MEMPESONA — BATEALIT

FILE UTAMA
- jepara_mempesona_batealit.html: file tunggal berisi HTML, CSS, JavaScript, dan foto tertanam (untuk salinan mandiri).
- jepara_mempesona_batealit_kode.txt: salinan seluruh kode HTML mandiri.
- jepara_mempesona_batealit_halaman.html: versi ringan yang menggunakan folder assets/ di sampingnya.
- paket_jepara_mempesona_batealit.zip: berisi versi ringan dan semua foto di folder assets/.

CARA MEMBUKA VERSI RINGAN
1. Ekstrak seluruh isi ZIP (jangan hanya mengambil file HTML).
2. Buka jepara_mempesona_batealit_halaman.html di browser. Folder assets harus tetap berada di samping file HTML.

CARA MENCOBA DI GOOGLE SITES
Google Sites dapat membatasi panjang kode Embed. File kode mandiri memiliki foto yang tertanam, sehingga ukurannya cukup besar. Kalau kode tidak diterima, jangan dipotong. Gunakan versi ringan dengan folder assets yang di-host bersama sebagai website statis, lalu sematkan URL situs tersebut ke Google Sites.

CATATAN KONTEN
- Agrowisata tidak dimasukkan sebagai kategori, destinasi, atau bagian deskripsi.
- HTML menampilkan data HTM, jam, akses, dan rating hanya bila ada isinya di materi. Profil budaya/tradisi/religi/sejarah tidak dipaksa mempunyai info HTM/jam/rating.
- Foto 1–40 diekstrak dari dua PDF; foto 41–42 berasal dari dua gambar yang dikirim terpisah. Foto tambahan Wono Pinus Setro dan destinasi sebelumnya juga disertakan.
- Informasi faktual mengikuti bahan pengguna dan belum diverifikasi independen. Pastikan kembali tarif, jadwal, keselamatan, titik peta, dan izin penggunaan foto sebelum publikasi.
- Perhatian: foto nomor 24 pada PDF lanjutan tampak memuat tulisan “Makam Mbah Joyo Kusumo”, sementara pembagian yang diberikan menempatkannya pada “Makam Mbah Abdus Salam”. Cek lagi sebelum dipublikasikan.
